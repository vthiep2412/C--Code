// C++ program to implement radix sort
#include <bits/stdc++.h>
using namespace std;

// counting sort implementation
void count_sort(int arr[], int n, int pos)
{
    // count array initialized to 0
    int count[10] = { 0 };

    // count frequency of each digit at the given place
    for (int i = 0; i < n; i++) {
        count[(arr[i] / pos) % 10]++;
    }

    // perform prefix sum (for stable sort)
    for (int i = 1; i < 10; i++) {
        count[i] += count[i - 1];
    }

    // store the result in a temporary array in reverse order
    int ans[n];
    for (int i = n - 1; i >= 0; i--) {
        ans[--count[(arr[i] / pos) % 10]] = arr[i];
    }

    // copy the sorted elements in reverse order for decreasing sort
    int idx = n - 1;
    for (int i = 0; i < n; i++) {
        arr[idx--] = ans[i];
    }
}

// function to implement radix sort
void radix_sort(int arr[], int n)
{
    // find the maximum element
    int k = *max_element(arr, arr + n);

    // iterate through every digit place
    for (int pos = 1; (k / pos) > 0; pos *= 10) {
        count_sort(arr, n, pos);
    }
}

// driver code
int main()
{
    int n;
    cin>>n;
    int a[n];
    for (int j=0;j<n;j++)
    {
        cin>>a[j];
    }
    radix_sort(a, n);

    // displaying the result
    cout << "Array after performing radix sort : " << endl;
    for (int i = 0; i < n; i++) {
        cout << a[i] << " ";
    }
    return 0;
}   