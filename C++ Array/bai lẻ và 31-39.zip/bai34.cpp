#include <bits/stdc++.h>
using namespace std;

int main() {
    int n,cnt=1;
    cin >> n;
    vector<int> a;
    vector<int> b,c;
    for (int j = 0; j < n; j++) {
        cin>>a[j];
    }

    for (int j = 0; j < n; j++) {
        if(a[j] > 0) {
            b.push_back(a[j]);
        }
        else {
            c.push_back(a[j]);
        }
    }
    a.clear();
    a.insert(a.end(), b.begin(), b.end());
    a.insert(a.end(), c.begin(), c.end());
    for (int j = 0; j < n; j++) {
        cout<<a[j]<<" ";
    }

}